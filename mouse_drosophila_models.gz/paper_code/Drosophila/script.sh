#!/bin/bash

nchain=11760
l=18
niter=1
neq=1000000
nmeas=1000
ninter=100
kint=1.15
nstate=213
es=-0.1
e11=-0.1
e22=-0.05
e12=-0.05

t=$((4*${l}*${l}*${l}))
td=$((10*${nmeas}*${niter}))
sb=$((13+2+${nstate}))

sed -i.back -e '1c\'$'\n '$nchain' ::Nchain' input.dat
sed -i.back -e '2c\'$'\n '$l' ::L' input.dat
sed -i.back -e '3c\'$'\n '$niter' ::Niter' input.dat
sed -i.back -e '4c\'$'\n '$neq' ::Neq' input.dat
sed -i.back -e '5c\'$'\n '$nmeas' ::Nmeas' input.dat
sed -i.back -e '6c\'$'\n '$ninter' ::Ninter' input.dat
sed -i.back -e '7c\'$'\n '$kint' ::kint' input.dat
sed -i.back -e '8c\'$'\n '$nstate' ::Nstate' input.dat
sed -i.back -e '9c\'$'\n '$es' ::Es' input.dat
sed -i.back -e '10c\'$'\n '$e11' ::E11' input.dat
sed -i.back -e '11c\'$'\n '$e22' ::E22' input.dat
sed -i.back -e '12c\'$'\n '$e12' ::E12' input.dat
sed -i.back -e '3c\'$'\n integer,dimension(2,'$nchain') ::config' global.var
sed -i.back -e '4c\'$'\n integer,dimension('$sb','$t') ::bittable' global.var
sed -i.back -e '8c\'$'\n real,dimension(3,'$nchain') ::dr' global.var
sed -i.back -e '9c\'$'\n integer,dimension('$nchain') ::state' global.var
sed -i.back -e '10c\'$'\n integer,dimension(3,'$nstate') ::TAD' global.var
sed -i.back -e '11c\'$'\n integer,dimension('$nchain') ::compartement' global.var

make clean
make
echo 'Lunching the program'
time ./lat

