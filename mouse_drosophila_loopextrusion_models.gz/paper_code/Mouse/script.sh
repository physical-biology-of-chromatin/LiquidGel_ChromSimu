#!/bin/bash

nchain=11505
l=18
niter=1
neq=1000000
nmeas=1000
ninter=100
kint=1.15
ntad=64
nloop=96
etada=-0.06
etadb=-0.04
eloop=-0.3
eaa=-0.02
ebb=-0.03
eab=0.0

t=$((4*${l}*${l}*${l}))
td=$((10*${nmeas}*${niter}))
sb=$((13+2+${ntad}+${nloop}))

sed -i.back -e '1c\'$'\n '$nchain' ::Nchain' input.dat
sed -i.back -e '2c\'$'\n '$l' ::L' input.dat
sed -i.back -e '3c\'$'\n '$niter' ::Niter' input.dat
sed -i.back -e '4c\'$'\n '$neq' ::Neq' input.dat
sed -i.back -e '5c\'$'\n '$nmeas' ::Nmeas' input.dat
sed -i.back -e '6c\'$'\n '$ninter' ::Ninter' input.dat
sed -i.back -e '7c\'$'\n '$kint' ::kint' input.dat
sed -i.back -e '8c\'$'\n '$ntad' ::NTAD' input.dat
sed -i.back -e '9c\'$'\n '$nloop' ::NLoop' input.dat
sed -i.back -e '10c\'$'\n '$etada' ::ETADA' input.dat
sed -i.back -e '11c\'$'\n '$etadb' ::ETADB' input.dat
sed -i.back -e '12c\'$'\n '$eloop' ::ELoop' input.dat
sed -i.back -e '13c\'$'\n '$eaa' ::EAA' input.dat
sed -i.back -e '14c\'$'\n '$ebb' ::EBB' input.dat
sed -i.back -e '15c\'$'\n '$eab' ::EAB' input.dat
sed -i.back -e '3c\'$'\n integer,dimension(2,'$nchain') ::config' global.var
sed -i.back -e '4c\'$'\n integer,dimension('$sb','$t') ::bittable' global.var
sed -i.back -e '8c\'$'\n real,dimension(3,'$nchain') ::dr' global.var
sed -i.back -e '9c\'$'\n integer,dimension('$nchain') ::state' global.var
sed -i.back -e '10c\'$'\n integer,dimension(3,'$ntad') ::TAD' global.var
sed -i.back -e '11c\'$'\n integer,dimension('$nchain') ::Loop' global.var
sed -i.back -e '12c\'$'\n integer,dimension('$nchain') ::compartement' global.var

make clean
make
echo 'Lunching the program'
time ./lat

