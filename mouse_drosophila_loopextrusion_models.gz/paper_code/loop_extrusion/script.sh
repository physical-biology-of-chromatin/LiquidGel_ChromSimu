nchain=9827
l=17
niter=1
nequ=1000000
nmeas=1000
ninter=1000
kint=1.2
kb=2.7e-6
ku=2e-6
km=2e-3
Ea=10.
Nlef=200
tadsize=400

t=$((4*${l}*${l}*${l}))
td=$((10*${nmeas}*${niter}))

sed -i.back -e '1c\'$'\n '$nchain' ::Nchain' input.dat
sed -i.back -e '2c\'$'\n '$l' ::L' input.dat
sed -i.back -e '3c\'$'\n '$niter' ::Niter' input.dat
sed -i.back -e '4c\'$'\n '$nequ' ::Nequ' input.dat
sed -i.back -e '5c\'$'\n '$nmeas' ::Nmeas' input.dat
sed -i.back -e '6c\'$'\n '$ninter' ::Ninter' input.dat
sed -i.back -e '7c\'$'\n '$kint' ::kint' input.dat
sed -i.back -e '8c\'$'\n '$kb' ::kb' input.dat
sed -i.back -e '9c\'$'\n '$ku' ::ku' input.dat
sed -i.back -e '10c\'$'\n '$km' ::km' input.dat
sed -i.back -e '11c\'$'\n '$Ea' ::Ea' input.dat
sed -i.back -e '12c\'$'\n '$Nlef' ::Nlef' input.dat
sed -i.back -e '13c\'$'\n '$tadsize' ::TAD_size' input.dat
sed -i.back -e '3c\'$'\n integer,dimension(2,'$nchain') ::config' global.var
sed -i.back -e '4c\'$'\n integer,dimension(13,'$t') ::bittable' global.var
sed -i.back -e '8c\'$'\n real,dimension(3,'$nchain') ::dr,dleg' global.var
sed -i.back -e '9c\'$'\n integer,dimension(2,'$nchain') ::contact' global.var
sed -i.back -e '10c\'$'\n integer,dimension('$nchain') ::boundary' global.var

make clean
make

echo 'Lancement du programme'
time ./lat
