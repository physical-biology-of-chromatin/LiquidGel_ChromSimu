to run each (i.e. Mouse or Drosophila) chromosome
"cd Mouse" (or "cd Drosophila")
"./script.sh"
