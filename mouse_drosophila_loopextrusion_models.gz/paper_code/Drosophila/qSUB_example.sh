#!/bin/bash
#
### variables SGE
### shell du job
#$ -S /bin/bash
### nom du job (a changer)
#$ -N Chromatin_test
### file d'attente (a changer)
#$ -q monointeldeb48,monointeldeb128,r820deb768
### charger l'environnement utilisateur pour SGE
#$ -cwd
### exporter les variables d'environnement sur tous les noeuds d'execution
#$ -V
### mails en debut et fin d'execution
#$ -m be
### log files
#$ -o /home/hsalari/logs
#$ -e /home/hsalari/logs 
# aller dans le repertoire de travail/soumission
# important, sinon, le programme est lancé depuis ~/
cd ${SGE_O_WORKDIR}
# init env (should be in ~/.profile)
source /usr/share/lmod/lmod/init/bash
### configurer l'environnement (a changer)
module load GCC/7.2.0
### execution du programme (a changer avec votre executable)
###EXECDIR=${HOME}/Formations/Sequentiel
###${EXECDIR}/script_executable < Monfichierdedata > monfichierresultat
cd copolymer
cd size9827
cd hetero24
cd fly/chr2L
cd TAD_213_energy_-1e-1
cd main
./parallel_script.sh
# fin
